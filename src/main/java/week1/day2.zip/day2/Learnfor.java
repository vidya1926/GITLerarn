package week1.day2;

public class Learnfor {

	public static void main(String[] args) {

		int n = 2;

		System.out.println(n * 2);
		System.out.println(n * 3);
		System.out.println(n * 4);
		System.out.println(n * 5);
		System.out.println("**********************");
//Print the multiplication of 2 -->1 to 15 
//syntax
//for(intialize the start point, range to stop ,increment)

		for (int i = 2; i < 16; i++)
		// i=2 ;2<16; 2++ -->2+1 -->3
		{
			System.out.println(n * i);

		}

	}
}
