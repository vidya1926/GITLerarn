package week1.day2;

public class LearnSwitch {

	public static void main(String[] args) {
		
		String browser="hrome";
		
		//works for checking equality
		switch(browser) {
		
		case "Chrome":{
			System.out.println("Execute in Chrome");
			break; //jump statement -->to stop the execution when the condition is true
		}
		
		case "Edge":{
			System.out.println("Execute in edge");
			break;
		}
		
		case "IE":{
			System.out.println("IE");
			break;
		}
		//F11
		
		}

	}

}
