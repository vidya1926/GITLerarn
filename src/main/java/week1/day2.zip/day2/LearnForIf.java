package week1.day2;

public class LearnForIf {

	public static void main(String[] args) {
		
		//to print only the even number between 1 to 15
		
		//int n=10;
		
		for(int i=1;i<16;i++) {
		if(i%2==0) {
			//1==0 -->false
			//2-->0==0 -->true
			//3-->1==0 -->false
			System.out.println(i +"The number is even" );
		}
		
		}
	}

	// 1 to 15
	//1%2 ==0
	//2%2 ==0
	//3%2 ==0
	//4%2 ==0
	
	
}
