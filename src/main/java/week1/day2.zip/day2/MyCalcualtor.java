package week1.day2;

public class MyCalcualtor {

	public static void main(String[] args) {
	
		LearnMethods math=new LearnMethods();
		int add = math.add(10, 10);
		math.sub(add, 25);
		math.funName("Subraction");
		}

}
